SprityBirdInSwift
=================

Port of SprityBird (Flappy Bird clone) to Swift from Alexis Creuzot's Objective-C source.

Authors
=======
- Frederick Siu - [github](https://github.com/fsiu)
- Based on Objective-C code by [Alexis Creuzot](https://github.com/kirualex/SprityBird)
